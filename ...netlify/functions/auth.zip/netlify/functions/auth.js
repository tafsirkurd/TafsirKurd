const jwt = require('jsonwebtoken');

exports.handler = async (event, context) => {
    // Set CORS headers for all responses
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Content-Type': 'application/json'
    };

    // Handle preflight OPTIONS request
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: ''
        };
    }

    // Only allow POST requests
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            headers,
            body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

    try {
        const { email, password } = JSON.parse(event.body);

        // Validate credentials against environment variables
        const adminEmail = process.env.ADMIN_EMAIL;
        const adminPassword = process.env.ADMIN_PASSWORD;

        if (!adminEmail || !adminPassword) {
            console.error('Missing admin credentials in environment variables');
            return {
                statusCode: 500,
                headers,
                body: JSON.stringify({
                    success: false,
                    message: 'Server configuration error'
                })
            };
        }

        // Check credentials
        if (email === adminEmail && password === adminPassword) {
            // Create JWT token
            const token = jwt.sign(
                {
                    email: adminEmail,
                    role: 'admin',
                    iat: Math.floor(Date.now() / 1000)
                },
                process.env.JWT_SECRET || 'fallback-secret-key-change-in-production',
                { expiresIn: '24h' }
            );

            const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    message: 'Login successful',
                    user: {
                        email: adminEmail,
                        role: 'admin'
                    },
                    token: token,
                    expires: expiresAt.toISOString()
                })
            };
        } else {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({
                    success: false,
                    message: 'Invalid credentials'
                })
            };
        }
    } catch (error) {
        console.error('Auth function error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                success: false,
                message: 'Internal server error'
            })
        };
    }
};